/*
 * HuskarUI
 *
 * Copyright (C) mengps (MenPenS) (MIT License)
 * https://github.com/mengps/HuskarUI
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 * - The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.
 * - The Software is provided "as is", without warranty of any kind, express or
 *   implied, including but not limited to the warranties of merchantability,
 *   fitness for a particular purpose and noninfringement. In no event shall the
 *   authors or copyright holders be liable for any claim, damages or other
 *   liability, whether in an action of contract, tort or otherwise, arising from,
 *   out of or in connection with the Software or the use or other dealings in the
 *   Software.
 */

import QtQuick
import QtQuick.Controls.impl
import QtQuick.Templates as T
import HuskarUI.Basic

T.TextField {
    id: control

    enum IconPosition {
        Position_Left = 0,
        Position_Right = 1
    }

    enum Type {
        Type_Outlined = 1,
        Type_Dashed = 2,
        Type_Borderless = 3,
        Type_Underlined = 4,
        Type_Filled = 5
    }

    signal clickClear()

    property bool animationEnabled: HusTheme.animationEnabled
    property bool darkMode: HusTheme.isDark
    property bool active: hovered || activeFocus
    property int type: HusInput.Type_Outlined
    property bool showShadow: false
    property var iconSource: 0 ?? ''
    property int iconSize: parseInt(themeSource.fontSizeIcon) * sizeRatio
    property int iconPosition: HusInput.Position_Left
    property var clearEnabled: false ?? ''
    property var clearIconSource: HusIcon.CloseCircleFilled ?? ''
    property int clearIconSize: parseInt(themeSource.fontSizeClearIcon) * sizeRatio
    property int clearIconPosition: HusInput.Position_Right
    readonly property int leftIconPadding: iconPosition === HusInput.Position_Left ? __private.iconSize : 0
    readonly property int rightIconPadding: iconPosition === HusInput.Position_Right ? __private.iconSize : 0
    readonly property int leftClearIconPadding: clearIconPosition === HusInput.Position_Left ? __private.clearIconSize : 0
    readonly property int rightClearIconPadding: clearIconPosition === HusInput.Position_Right ? __private.clearIconSize : 0
    property color colorIcon: enabled ? themeSource.colorIcon : themeSource.colorIconDisabled
    property alias colorText: control.color
    property color colorBg: {
        if (enabled) {
            if (type === HusInput.Type_Borderless || type === HusInput.Type_Underlined) {
                return 'transparent';
            } else if (type === HusInput.Type_Filled) {
                return themeSource.colorBgFilled;
            } else {
                return themeSource.colorBg;
            }
        } else {
            return themeSource.colorBgDisabled;
        }
    }
    property color colorShadow: enabled ? themeSource.colorShadow : 'transparent'
    property HusRadius radiusBg: HusRadius { all: themeSource.radiusBg }
    property HusBorder borderBg: HusBorder {
        color: enabled ? active ? themeSource.colorBorderHover :
                                  themeSource.colorBorder : themeSource.colorBorderDisabled
    }
    property string sizeHint: 'normal'
    property real sizeRatio: HusTheme.sizeHint[sizeHint]
    property string contentDescription: ''
    property var themeSource: HusTheme.HusInput

    property Component iconDelegate: HusIconText {
        leftPadding: control.iconPosition === HusInput.Position_Left ? 10 * sizeRatio: 0
        rightPadding: control.iconPosition === HusInput.Position_Right ? 10 * sizeRatio: 0
        iconSource: control.iconSource
        iconSize: control.iconSize
        colorIcon: control.colorIcon
    }
    property Component clearIconDelegate: HusIconText {
        leftPadding: control.clearIconPosition === HusInput.Position_Left ? (control.leftIconPadding > 0 ? 5 : 10) * sizeRatio : 0
        rightPadding: control.clearIconPosition === HusInput.Position_Right ? (control.rightIconPadding > 0 ? 5 : 10) * sizeRatio : 0
        iconSource: control.length > 0 ? control.clearIconSource : 0
        iconSize: control.clearIconSize
        colorIcon: {
            if (control.enabled) {
                return __tapHandler.pressed ? control.themeSource.colorClearIconActive :
                                              __hoverHandler.hovered ? control.themeSource.colorClearIconHover :
                                                                       control.themeSource.colorClearIcon;
            } else {
                return control.themeSource.colorClearIconDisabled;
            }
        }

        Behavior on colorIcon { enabled: control.animationEnabled; ColorAnimation { duration: HusTheme.Primary.durationMid } }

        HoverHandler {
            id: __hoverHandler
            enabled: (control.clearEnabled === 'active' || control.clearEnabled === true) && !control.readOnly
            cursorShape: Qt.PointingHandCursor
        }

        TapHandler {
            id: __tapHandler
            enabled: (control.clearEnabled === 'active' || control.clearEnabled === true) && !control.readOnly
            onTapped: {
                control.clear();
                control.clickClear();
            }
        }
    }
    property Component bgDelegate: Item {
        Loader {
            anchors.fill: parent
            visible: active
            active: control.type === HusInput.Type_Outlined || control.type === HusInput.Type_Filled
            sourceComponent: HusRectangleInternal {
                color: control.colorBg
                border.color: control.borderBg.color
                border.width: control.borderBg.width
                border.pixelAligned: control.borderBg.pixelAligned
                radius: control.radiusBg.all
                topLeftRadius: control.radiusBg.topLeft
                topRightRadius: control.radiusBg.topRight
                bottomLeftRadius: control.radiusBg.bottomLeft
                bottomRightRadius: control.radiusBg.bottomRight
            }
        }

        Loader {
            width: parent.width
            height: 1
            anchors.bottom: parent.bottom
            visible: active
            active: control.type === HusInput.Type_Underlined
            sourceComponent: HusRectangleInternal {
                color: control.borderBg.color
            }
        }

        Loader {
            anchors.fill: parent
            visible: active
            active: control.type === HusInput.Type_Dashed
            sourceComponent: HusRectangle {
                color: control.colorBg
                border.color: control.borderBg.color
                border.width: control.borderBg.width
                border.style: Qt.DashLine
                radius: control.radiusBg.all
                topLeftRadius: control.radiusBg.topLeft
                topRightRadius: control.radiusBg.topRight
                bottomLeftRadius: control.radiusBg.bottomLeft
                bottomRightRadius: control.radiusBg.bottomRight
            }
        }
    }

    objectName: '__HusInput__'
    focus: true
    implicitWidth: implicitBackgroundWidth + leftInset + rightInset
                   || Math.max(contentWidth, __placeholder.implicitWidth) + leftPadding + rightPadding
    implicitHeight: Math.max(implicitBackgroundHeight + topInset + bottomInset,
                             contentHeight + topPadding + bottomPadding,
                             __placeholder.implicitHeight + topPadding + bottomPadding)
    padding: 6 * sizeRatio
    leftPadding: (__private.leftHasIcons ? 5 : 10) * sizeRatio + leftIconPadding + leftClearIconPadding
    rightPadding: (__private.rightHasIcons ? 5 : 10) * sizeRatio + rightIconPadding + rightClearIconPadding
    color: enabled ? themeSource.colorText : themeSource.colorTextDisabled
    placeholderTextColor: enabled ? themeSource.colorPlaceholderText : themeSource.colorPlaceholderTextDisabled
    selectedTextColor: themeSource.colorTextSelected
    selectionColor: themeSource.colorSelection
    font {
        family: themeSource.fontFamily
        pixelSize: parseInt(themeSource.fontSize) * sizeRatio
    }
    background: Item {
        Loader {
            anchors.fill: parent
            active: control.showShadow
            sourceComponent: HusShadow {
                source: __bgLoader
                shadowColor: control.colorShadow
                shadowOpacity: control.enabled && control.active ? 0.2 : 0
                shadowBlur: 0.3
            }
        }

        Loader {
            id: __bgLoader
            anchors.fill: parent
            visible: !control.showShadow
            sourceComponent: control.bgDelegate
        }
    }

    Behavior on colorText { enabled: control.animationEnabled; ColorAnimation { duration: HusTheme.Primary.durationMid } }
    Behavior on colorBg { enabled: control.animationEnabled; ColorAnimation { duration: HusTheme.Primary.durationMid } }
    Behavior on borderBg.color { enabled: control.animationEnabled; ColorAnimation { duration: HusTheme.Primary.durationMid } }

    QtObject {
        id: __private
        property bool leftHasIcons: control.leftIconPadding + control.leftClearIconPadding > 0
        property bool rightHasIcons: control.rightIconPadding + control.rightClearIconPadding > 0
        property int iconSize: __iconLoader.active ? __iconLoader.width : 0
        property int clearIconSize: __clearIconLoader.active ? __clearIconLoader.width : 0
    }

    PlaceholderText {
        id: __placeholder
        x: control.leftPadding
        y: control.topPadding
        width: control.width - (control.leftPadding + control.rightPadding)
        height: control.height - (control.topPadding + control.bottomPadding)
        text: control.placeholderText
        font: control.font
        color: control.placeholderTextColor
        verticalAlignment: control.verticalAlignment
        visible: !control.length && !control.preeditText && (!control.activeFocus || control.horizontalAlignment !== Qt.AlignHCenter)
        elide: Text.ElideRight
        renderType: control.renderType
    }

    Loader {
        id: __iconLoader
        active: control.iconSource !== 0 && control.iconSource !== ''
        anchors.left: control.iconPosition === HusInput.Position_Left ? parent.left : undefined
        anchors.right: control.iconPosition === HusInput.Position_Right ? parent.right : undefined
        anchors.verticalCenter: parent.verticalCenter
        sourceComponent: control.iconDelegate
    }

    Loader {
        id: __clearIconLoader
        active: control.enabled && !control.readOnly && control.clearIconSource !== 0 && control.clearIconSource !== ''
                && (control.clearEnabled === true || (control.clearEnabled === 'active' && control.active))
        anchors.left: {
            if (control.clearIconPosition === HusInput.Position_Left) {
                return __iconLoader.active && control.iconPosition === HusInput.Position_Left ? __iconLoader.right : parent.left;
            } else {
                return undefined;
            }
        }
        anchors.right: {
            if (control.clearIconPosition === HusInput.Position_Right) {
                return __iconLoader.active && control.iconPosition === HusInput.Position_Right ? __iconLoader.left : parent.right;
            } else {
                return undefined;
            }
        }
        anchors.verticalCenter: parent.verticalCenter
        sourceComponent: control.clearIconDelegate
    }

    Accessible.role: Accessible.EditableText
    Accessible.editable: !control.readOnly
    Accessible.description: control.contentDescription
}
